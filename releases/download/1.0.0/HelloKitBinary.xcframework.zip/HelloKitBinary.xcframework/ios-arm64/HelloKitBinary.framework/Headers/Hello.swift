//
//  Hello.swift
//  HelloKitBinary
//
//  Created by yafei li on 2025/11/5.
//


import Foundation

public struct Hello {
    public static func say() -> String {
        return "Hello from HelloKit! 🚀"
    }
}
