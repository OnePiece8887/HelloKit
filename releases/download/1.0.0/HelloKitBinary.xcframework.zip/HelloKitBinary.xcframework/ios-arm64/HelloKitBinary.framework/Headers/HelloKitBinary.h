//
//  HelloKitBinary.h
//  HelloKitBinary
//
//  Created by yafei li on 2025/11/5.
//

#import <Foundation/Foundation.h>

//! Project version number for HelloKitBinary.
FOUNDATION_EXPORT double HelloKitBinaryVersionNumber;

//! Project version string for HelloKitBinary.
FOUNDATION_EXPORT const unsigned char HelloKitBinaryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HelloKitBinary/PublicHeader.h>


